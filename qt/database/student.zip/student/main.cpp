﻿#include "mainwindow.h"
#include <QApplication>
#include <QCoreApplication>
#include <QDebug>
#include <QSqlDatabase>
#include <QMessageBox>

bool opendatabase();

int main(int argc, char *argv[])
{
    // 可以在此处创建 QCoreApplication 实例，确保数据库操作能够顺利进行
    QCoreApplication::setApplicationName("StudentApp");


    QApplication a(argc, argv);    opendatabase();
    MainWindow w;
    w.show();

    return a.exec();
}

bool opendatabase()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:\\Users\\wwwcz\\Documents\\Tencent Files\\1637150660\\FileRecv\\sc.db");  //平时debug正常用
    //mydb.setDatabaseName("./student.db"); //release用
    if (!db.open()) {
        QMessageBox::critical(nullptr, QObject::tr("Cannot open database"),
                              QObject::tr("Unable to establish a database connection.\n"
                                          "This example needs SQLite support. Please read "
                                          "the Qt SQL driver documentation for information how "
                                          "to build it.\n\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        return false;
    }
    return true;
}
