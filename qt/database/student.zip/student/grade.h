#ifndef GRADE_H
#define GRADE_H

#include <QMainWindow>
#include <QSqlQueryModel>
#include <QMessageBox>
#include <QSqlQuery>
#include "ui_grade.h"

class Grade : public QMainWindow
{
    Q_OBJECT

public:
    explicit Grade(QMainWindow *parent = 0, int f = 0, QString sname = "");

    ~Grade();
    int flag= 0;
    QString Sname;

private slots:
    void on_pushButton_exit_clicked();  // 退出按钮
    void on_pushButton_add_clicked();   // 添加成绩按钮
    void on_pushButton_delete_clicked(); // 删除成绩按钮
    void init();

private:
    Ui::grade *ui;
};

#endif // GRADE_H
