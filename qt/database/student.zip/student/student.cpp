﻿#include "student.h"
#include "ui_student.h"
#include<QDebug>
#include<QSqlQueryModel>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QValueAxis>
#include<QSqlError>
#include <QSqlQuery>
#include <QMessageBox>

#pragma execution_character_set("utf-8")//设置中文= =
student::student(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::student)
{
    ui->setupUi(this);

}

student::~student()
{
    delete ui;
}

void student::on_pushButton_clicked()
{
    close();
}
void student::init()
{
    qDebug()<<stuName;
    QString sql_stu;
    sql_stu="select Sname as 姓名 ,Sno as 学号,Ssex as 性别 ,Sdept as 学院, 奖学金  from student where Sname='"+stuName+"'";
    QSqlQueryModel *modelx=new QSqlQueryModel;
    modelx->setQuery(sql_stu);
    ui->tableView->setModel(modelx);
}

void student::on_pushButton_exit_clicked()
{
    grade = new Grade(0, 0, stuName);
    grade->show();
}



void student::on_pushButton_draw_charts_clicked()
{
    // 创建柱状图系列
    QBarSeries *series = new QBarSeries();

    // 创建查询
    QSqlQuery query;
    query.prepare("SELECT STUDENT.Sname, SC.Grade, COURSE.Cname "
                  "FROM SC "
                  "JOIN STUDENT ON SC.Sno = STUDENT.Sno "
                  "JOIN COURSE ON SC.Cno = COURSE.Cno");

    if (!query.exec()) {
        QMessageBox::warning(this, "查询失败", "无法获取成绩数据：" + query.lastError().text());
        return;
    }

    // 准备数据
    QBarSet *set = new QBarSet("成绩");
    QStringList courseNames; // 用于存储课程名称
    while (query.next()) {
        QString Sname = query.value("Sname").toString();
        int grade = query.value("Grade").toInt();
        QString courseName = query.value("Cname").toString();

        *set << grade;  // 向柱状图系列中添加成绩数据
        courseNames.append(courseName);  // 添加课程名称到列表
    }

    // 将数据添加到柱状图系列
    series->append(set);

    // 创建图表对象
    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("学生成绩分布");
    chart->setAnimationOptions(QChart::SeriesAnimations);

    // 创建坐标轴
    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(courseNames);  // 使用课程名称作为X轴的标签
    chart->setAxisX(axisX, series);
    chart->setAxisY(new QValueAxis(), series);

    // 创建图表视图并显示图表
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    ui->verticalLayout->addWidget(chartView); //
}

