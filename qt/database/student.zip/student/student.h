﻿#ifndef STUDENT_H
#define STUDENT_H

#include <QMainWindow>
#include"grade.h"
namespace Ui {
class student;
}

class student : public QMainWindow
{
    Q_OBJECT

public:
    explicit student(QWidget *parent = 0);
    ~student();
    void init();
    QString stuName;
private slots:
    void on_pushButton_clicked();

    void on_pushButton_exit_clicked();

    void on_pushButton_draw_charts_clicked();

private:
    Ui::student *ui;
    Grade *grade;
};

#endif // STUDENT_H
