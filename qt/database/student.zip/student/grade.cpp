#include "grade.h"
#include "ui_grade.h"
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QMessageBox>
#include <QDebug>
#include <QMainWindow>
Grade::Grade(QMainWindow *parent, int f, QString sname) :
    QMainWindow(parent),
    flag(f),
    Sname(sname),
    ui(new Ui::grade)
{
    ui->setupUi(this);
    init();
}
void Grade::init(){
    if(flag==1){
        QSqlQueryModel *model1 = new QSqlQueryModel;
        model1->setQuery("select Sname as 姓名 ,student.Sno as 学号,Cname as 课程,Course.Cno as 课程号,Grade as 成绩  from student,sc,course where student.sno = sc.sno and sc.cno =course.cno");
        ui->tableView->setModel(model1);
    }
    if(flag==0){
        QSqlQueryModel *model2 = new QSqlQueryModel;
        model2->setQuery("select Sname as 姓名 ,student.Sno as 学号,Cname as 课程,Course.Cno as 课程号,Grade as 成绩  from student,sc,course where student.sno = sc.sno and sc.cno =course.cno and Sname='"+Sname+"'" );
        ui->tableView->setModel(model2);
        ui->pushButton_add->setVisible(false);
        ui->pushButton_delete->setVisible(false);
        ui->label->setVisible(false);
        ui->label_2->setVisible(false);
        ui->label_3->setVisible(false);
        ui->lineEdit_cno1->setVisible(false);
        ui->lineEdit_sno1->setVisible(false);
        ui->lineEdit_grade1->setVisible(false);
    }
}
// 初始化查询数据，显示所有成绩

Grade::~Grade()
{
    delete ui;
}

void Grade::on_pushButton_exit_clicked()
{
    close();
}

void Grade::on_pushButton_add_clicked()
{
    QString sno = ui->lineEdit_sno1->text(); // 用于输入学号的lineEdit控件
    QString cno = ui->lineEdit_cno1->text(); // 用于输入课程号的lineEdit控件
    int grade = ui->lineEdit_grade1->text().toInt(); // 用于输入成绩的lineEdit控件

    if (sno.isEmpty() || cno.isEmpty() || grade < 0 || grade > 100) {
        QMessageBox::warning(this, "输入错误", "请输入有效的学号、课程号和成绩！");
        return;
    }

    // 插入成绩的SQL语句
    QSqlQuery query;
    query.prepare("INSERT INTO SC (Sno, Cno, Grade) VALUES (:sno, :cno, :grade)");
    query.bindValue(":sno", sno);
    query.bindValue(":cno", cno);
    query.bindValue(":grade", grade);
    query.exec();


    // 更新表格数据
    QSqlQueryModel *model = new QSqlQueryModel;
    model->setQuery("select Sname as 姓名 ,student.Sno as 学号,Cname as 课程,Course.Cno as 课程号,Grade as 成绩  from student,sc,course where student.sno = sc.sno and sc.cno =course.cno");
    ui->tableView->setModel(model);
}

void Grade::on_pushButton_delete_clicked()
{
    QString sno = ui->lineEdit_sno1->text(); // 学号
    QString cno = ui->lineEdit_cno1->text(); // 课程号

    if (sno.isEmpty() || cno.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请输入学号和课程号！");
        return;
    }

    // 删除成绩的SQL语句
    QSqlQuery query;
    query.prepare("DELETE FROM SC WHERE Sno = :sno AND Cno = :cno");
    query.bindValue(":sno", sno);
    query.bindValue(":cno", cno);

    if (query.exec()) {
        QMessageBox::information(this, "成功", "成绩删除成功！");
    } else {
        QMessageBox::warning(this, "失败", "删除成绩失败！");
    }

    // 更新表格数据
    QSqlQueryModel *model = new QSqlQueryModel;
    model->setQuery("SELECT Sname AS 姓名, Sno AS 学号, Cno AS 课程号, Grade AS 成绩 FROM SC JOIN STUDENT ON SC.Sno = STUDENT.Sno");
    ui->tableView->setModel(model);
}


