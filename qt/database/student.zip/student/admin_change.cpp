﻿#include "admin_change.h"
#include "ui_admin_change.h"
#include<QSqlQueryModel>
#include<QMessageBox>
#include<QSqlError>
#include"admin.h"
#pragma execution_character_set("utf-8")//设置中文= =


bool opendatabase1()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("C:\\Users\\wwwcz\\Documents\\Tencent Files\\1637150660\\FileRecv\\sc.db");  //平时debug正常用
    //mydb.setDatabaseName("./student.db"); //release用
    if (!db.open()) {
        QMessageBox::critical(nullptr, QObject::tr("Cannot open database"),
                              QObject::tr("Unable to establish a database connection.\n"
                                          "This example needs SQLite support. Please read "
                                          "the Qt SQL driver documentation for information how "
                                          "to build it.\n\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        return false;
    }
    return true;
}









admin_change::admin_change(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::admin_change)
{
    ui->setupUi(this);
}

admin_change::~admin_change()
{
    delete ui;
}

void admin_change::on_pushButton_exit_clicked()
{
    close();
}

void admin_change::on_pushButton_enter_clicked()
{
    QString Sname, Sno, Ssex, Sage, Sdept, 奖学金, password;
    Sname = ui->lineEdit_Sname->text();
    Sno = ui->lineEdit_Sno->text();
    Ssex = ui->lineEdit_Ssex->text();
    Sage = ui->lineEdit_Sage->text();
    Sdept = ui->lineEdit_Sdept->text();
    奖学金 = ui->lineEdit_Money->text();
    password = ui->lineEdit_passowrd->text();

    if(ui->radioButton_add->isChecked())
    {
        // 检查学生是否已存在
        QString sql1 = "SELECT COUNT(*) FROM student WHERE Sname = :Sname";
        QSqlQuery query;
        query.prepare(sql1);
        query.bindValue(":Sname", Sname);
        query.exec();
        query.next(); // 移动到结果行
        int count = query.value(0).toInt();

        if(count > 0)
        {
            QMessageBox::about(NULL, "警告", "系统中已有这位学生");
        }
        else
        {
            // 插入新学生信息
            opendatabase1();
            QString sql2;
            QSqlQueryModel *model2=new QSqlQueryModel;
            sql2="insert into student values('"+Sno+"','"+Sname+"','"+Ssex+"','"+Sage+"','"+Sdept+"','"+奖学金+"','"+password+"')";
            model2->setQuery(sql2);
            admin ad;
            ad.init();
            QMessageBox::about(NULL,"提示","系统信息添加成功");
        }
    }
    else if(ui->radioButton_change->isChecked())
    {
        // 检查学生是否存在
        QString sql1 = "SELECT COUNT(*) FROM student WHERE Sname = :Sname";
        QSqlQuery query;
        query.prepare(sql1);
        query.bindValue(":Sname", Sname);
        query.exec();
        query.next(); // 移动到结果行
        int count = query.value(0).toInt();

        if(count == 0)
        {
            QMessageBox::about(NULL, "警告", "系统中没有这位学生");
        }
        else
        {
            QString sql2;
            QSqlQueryModel *model2=new QSqlQueryModel;
            sql2="update student set number ='"+Sno+"','"+Sname+"','"+Ssex+"','"+Sdept+"','"+奖学金+"','"+password+"'  where name='"+Sname+"'";
            model2->setQuery(sql2);
            admin ad;
            ad.init();
            QMessageBox::about(NULL,"提示","系统信息添加成功");
        }
    }
    else
    {
        QMessageBox::about(NULL, "警告", "请选择你要进行的操作");
    }
}
